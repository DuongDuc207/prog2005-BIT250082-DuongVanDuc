n=1
a = 32.5
b ="hello world"
print ("số nguyên là: ",n)
print("số thực là:",a)
print("chuỗi là:",b)