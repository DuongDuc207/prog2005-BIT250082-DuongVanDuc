Pi = 3.14
r = 5
print("chu vi là:",2*Pi*r)
