a=int(input("số nguyên a:"))
b=int(input("số nguyên b:"))
print ("Tổng",a+b)
print ("hiệu",a-b)
print ("Tích",a*b)
if b == 0:
    print("lỗi phép tính mời nhập lại")
else:
    print("Thương",a/b)