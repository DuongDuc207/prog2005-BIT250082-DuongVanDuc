def  sum_two_numbers(a, b):
    return a+b
kq=sum_two_numbers(4,7)
print("Tổng",kq)
