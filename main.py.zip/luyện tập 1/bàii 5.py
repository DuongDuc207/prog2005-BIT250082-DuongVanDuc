name="Duc dz"
age= 18
average_score = 7.3
print("Tên:", name)
print("Kiểu dữ liệu của name:", type(name))
print("Tuổi sau khi +1",age+1)
print("Kiểu dữ liệu của age:", type(age))
print(" doubled_score",average_score*2)
print("Kiểu dữ liệu của average_score:", type(average_score))